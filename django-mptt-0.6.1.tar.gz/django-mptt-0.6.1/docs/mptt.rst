========
``mptt``
========

..  toctree::
    :maxdepth: 1
    
    mptt.admin
    mptt.exceptions
    mptt.fields
    mptt.forms
    mptt.managers
    mptt.models
    mptt.utils

.. automodule:: mptt
    :members:
    :undoc-members:
